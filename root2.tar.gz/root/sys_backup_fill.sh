#!/bin/bash
#Backup
date=$(date +%Y%m%d.%H%M)

tar czf /u03/daily-$date.tar.gz /etc /var/logs
