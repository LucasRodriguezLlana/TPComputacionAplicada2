#!/bin/bash
#Fechas no laborables

cont=20220626
cont7=0
fecha=$(date +%Y%m%d)
cont2=0

function contador {
cont2=$fecha-$cont
if[$cont2=0]; 
#then
echo test
fi

if[$cont7=1]; 
#then
echo Es domingo
fi
}

