#!/bin/bash
#Backup
var_date=$(date +%Y%m%d.%H%M)

tar czf /u03/daily-$var_date.tar.gz /etc /var/logs
