#!/bin/bash
#Backup 2
var_date=$(date +%Y%m%d.%H%M)

tar czf /u03/weekly-$var_date.tar.gz /u01 /u02
