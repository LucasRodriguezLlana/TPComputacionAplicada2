#!/bin/bash
#Backup
var_date=$(date +%Y%m%d.%H%M)

tar czf etc_bkp_daily_${var_date}.tar.gz /etc
mv etc_bkp_daily_${var_date}.tar.gz /u03

tar cfz varlog_bkp_daily_${var_date}.tar.gz /var/logs
mv varlog_bkp_daily_${var_date}.tar.gz /u03
