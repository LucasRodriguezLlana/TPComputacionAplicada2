#!/bin/bash
#Backup weekly
var_date=$(date +%Y%m%d.%H%M)

tar czf u01_bkp_weekly_${var_date}.tar.gz /u01
mv u01_bkp_weekly_${var_date}.tar.gz /u03

tar czf u02_bkp_weekly_${var_date}.tar.gz /u02
mv u02_bkp_weekly_${var_date}.tar.gz /u03
